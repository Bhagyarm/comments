package com.comments.service;

import com.comments.entity.Comment;

import java.time.LocalDateTime;
import java.util.List;

public interface CommentService {



    List<Comment> getAllComments();
    List<Comment> getCommentsByUsername(String username);
    List<Comment> getCommentsByDate(LocalDateTime date);
    Comment saveComment(Comment comment);
    Comment updateComment(Long id, Comment comment);
    void deleteComment(Long id);

}


