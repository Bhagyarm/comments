package com.comments.service;

import com.comments.entity.Comment;
import com.comments.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CommentServiceImpl implements CommentService{

    @Autowired
    private CommentRepository commentRepository;
    @Override
    public List<Comment> getAllComments() {
        return commentRepository.findAll();
    }

    @Override
    public List<Comment> getCommentsByUsername(String username) {
        return commentRepository.findByby(username);
    }

    @Override
    public List<Comment> getCommentsByDate(LocalDateTime date) {
        return commentRepository.findByDateofcomment(date);
    }

    @Override
    public Comment saveComment(Comment comment) {
        return commentRepository.save(comment);
    }

    @Override
    public Comment updateComment(Long id, Comment comment) {
        if (commentRepository.existsById(id)) {
            comment.setId(id);
            return commentRepository.save(comment);
        }

        return null;
    }

    @Override
    public void deleteComment(Long id) {
        commentRepository.deleteById(id);

    }
}
