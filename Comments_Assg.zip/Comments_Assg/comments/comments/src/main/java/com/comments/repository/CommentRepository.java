package com.comments.repository;

import com.comments.entity.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface CommentRepository extends JpaRepository <Comment,Long>{

    List<Comment> findByby(String username);

    List<Comment> findByDateofcomment(LocalDateTime date);

}
